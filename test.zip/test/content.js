let href = window.location.href;

const sidebarRemovalSites = ["https://www.chess.com/play/online", "https://www.chess.com/play", "https://www.chess.com/live"];

sidebarRemovalSites.forEach(site => {
    if (href == site) {
        let sidebar = document.getElementById("board-layout-sidebar");
        sidebar.innerHTML = "";
    }
});
